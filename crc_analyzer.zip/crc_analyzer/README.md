# CRC Analyzer - Análise de Mapa de Responsabilidades de Crédito

Aplicação web para análise automática do Mapa de Responsabilidades de Crédito (CRC) do Banco de Portugal.

## Funcionalidades

- **Upload de PDF** do CRC obtido em bportugal.pt
- **Extração automática** de dados de créditos via OCR e parsing de PDF
- **Cálculo de métricas financeiras**:
  - Taxa de esforço
  - Endividamento total
  - Rácio de incumprimento
  - Score de saúde financeira (0-100)
- **Dashboard interativo** com gráficos Plotly
- **Recomendações personalizadas** baseadas na situação financeira
- **Simulador** com rendimento mensal ajustável

## Instalação

### Pré-requisitos

- Python 3.8+
- Tesseract OCR instalado no sistema
  - Ubuntu/Debian: `sudo apt-get install tesseract-ocr tesseract-ocr-por`
  - macOS: `brew install tesseract`
  - Windows: [Download do instalador](https://github.com/UB-Mannheim/tesseract/wiki)
- Poppler (para pdf2image)
  - Ubuntu/Debian: `sudo apt-get install poppler-utils`
  - macOS: `brew install poppler`
  - Windows: [Download](https://github.com/oschwartz10612/poppler-windows/releases/)

### Instalação

```bash
# Clonar ou extrair o projeto
cd crc_analyzer

# Criar ambiente virtual
python -m venv venv

# Ativar ambiente
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate   # Windows

# Instalar dependências
pip install -r requirements.txt

# Executar aplicação
python app.py
```

A aplicação estará disponível em `http://localhost:5000`

## Como usar

1. Obtenha o seu Mapa de Responsabilidades de Crédito em [bportugal.pt](https://www.bportugal.pt)
2. Faça upload do PDF na aplicação
3. Introduza o seu rendimento líquido mensal
4. Clique em "Analisar Mapa de Crédito"
5. Visualize o dashboard com análise completa

## Estrutura do Projeto

```
crc_analyzer/
├── app.py                  # Aplicação Flask principal
├── requirements.txt        # Dependências Python
├── templates/
│   └── index.html         # Interface web
├── static/
│   ├── css/               # Estilos (inline no HTML)
│   └── js/
│       └── app.js         # Lógica frontend
└── uploads/               # Pasta temporária para uploads
```

## Métricas Calculadas

| Métrica | Descrição | Limite Recomendado |
|---------|-----------|-------------------|
| Taxa de Esforço | Total prestações / rendimento | < 30-35% |
| Endividamento Anual | Dívida total / rendimento anual | < 3x |
| Score | Pontuação global de saúde financeira | > 60 |
| Incumprimentos | Nº de créditos em default | 0 |

## Notas Legais

- A app não acede diretamente aos dados do Banco de Portugal
- O utilizador deve obter o PDF do CRC através do portal oficial
- A análise é meramente informativa e não substitui aconselhamento financeiro profissional
- Nenhum dado é armazenado em servidores - processamento local

## Licença

MIT License
